/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.politecnicomalaga.concesionario;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Boolean.parseBoolean;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author juanjemc
 */
public class ControladorVehiculos {

    public static boolean writeText(String fileName, String data) {

        //Grabación en texto
        FileWriter fo = null;
        PrintWriter pw = null;
        boolean resultado = false;

        try {

            fo = new FileWriter(fileName); //Abrimos el fichero, modo append false
            pw = new PrintWriter(fo); //Creamos el ayudante

            pw.print(data);

            pw.flush();

            fo.close();
            fo = null;
            resultado = true;

        } catch (IOException e) {

            System.out.println(e.getMessage());

        } finally {
            if (fo != null) {
                try {
                    fo.close();
                } catch (IOException ioe) {
                    System.out.println(ioe.getMessage());
                }

            }
        }
        return resultado;

    }

    public static String readText(String fileName) {

        // lectura en texto
        String resultado = "";
        FileReader fi = null;
        Scanner sc = null;

        try {

            fi = new FileReader(fileName);
            sc = new Scanner(fi);

            while (sc.hasNext()) {

                resultado += sc.nextLine() + "\n";

            }
            fi.close();
            fi = null;

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (fi != null) {
                try {
                    fi.close();
                } catch (IOException ioe) {
                    System.out.println(ioe.getMessage());
                }
            }
        }
        return resultado;

    }

    public static void grabarAFichero(String filename, Flota miFlota) {
        try {

            String Contenido = "";
            Contenido += miFlota.toString();
            Contenido += miFlota.getMisVehiculos().toString();

            if (ControladorVehiculos.writeText(filename, Contenido)) {
                System.out.println("Proceso de volcado a disco exitoso");

            } else {
                System.out.println("Error al escribir en disco. ¿Tiene espacio en el disco?");

            }
        } catch (Exception ex) {
            System.out.println("Error al grabar el equipo en CSV: " + ex.getMessage());
        }

    }

    public static int leerEquipoCSV(String filename, Flota miFlota) {
        try {
            int lineasCorrectas = 0;
            
            
            String contenido = ControladorVehiculos.readText(filename);
            String[] lineas = contenido.split("\n");
            
            for (int i = 1; i < lineas.length;i++) {
                String[] campos = lineas[i].split(":");

                String tipo = campos[3];
                
                String[] atributos = campos[1].split(";");
                //String marca, String modelo, String matricula, String tipo, float kilometraje, float precio, boolean disponible
                if (tipo.equals("Moto")) {
                    
                    String marca = atributos[0];
                    String modelo = atributos[1];
                    String matricula = atributos[2];
                    String tipoV = atributos[3];
                    float kilometraje = parseFloat(atributos[4]);
                    float precio = parseInt(atributos[5]);
                    boolean activo = parseBoolean(atributos[6]);
                    int cilindrada = parseInt(atributos[7]);
                    
                    Moto miMoto = new Moto(marca, modelo, matricula, tipoV, kilometraje, precio, activo, cilindrada);
                    
                    miFlota.putVehiculo(miMoto);
                    
                    lineasCorrectas++;
                    
                } else if (tipo.equals("Coche")) {
                    
                    String marca = atributos[0];
                    String modelo = atributos[1];
                    String matricula = atributos[2];
                    String tipoV = atributos[3];
                    float kilometraje = parseFloat(atributos[4]);
                    float precio = parseInt(atributos[5]);
                    boolean activo = parseBoolean(atributos[6]);
                    int pasajeros = parseInt(atributos[7]);
                    
                    Coche miCoche = new Coche(marca, modelo, matricula, tipoV, kilometraje, precio, activo, pasajeros);
                    
                    miFlota.putVehiculo(miCoche);
                    
                    lineasCorrectas++;

                } else if (tipo.equals("Camioneta")) {
                    
                    String marca = atributos[0];
                    String modelo = atributos[1];
                    String matricula = atributos[2];
                    String tipoV = atributos[3];
                    float kilometraje = parseFloat(atributos[4]);
                    float precio = parseInt(atributos[5]);
                    boolean activo = parseBoolean(atributos[6]);
                    float pesoMaximo = parseFloat(atributos[7]);
                    
                    Camioneta miCamioneta = new Camioneta(marca, modelo, matricula, tipoV, kilometraje, precio, activo, pesoMaximo);
                    
                    miFlota.putVehiculo(miCamioneta);
                    
                    lineasCorrectas++;
                    
                    
                    
                } else if (tipo.equals("Autocaravana")){
                   
                    String marca = atributos[0];
                    String modelo = atributos[1];
                    String matricula = atributos[2];
                    String tipoV = atributos[3];
                    float kilometraje = parseFloat(atributos[4]);
                    float precio = parseInt(atributos[5]);
                    boolean activo = parseBoolean(atributos[6]);
                    int camasDisponibles = parseInt(atributos[7]);
                    
                    Autocaravana miAutocaravana = new Autocaravana(marca, modelo, matricula, tipoV, kilometraje, precio, activo, camasDisponibles);
                    
                    miFlota.putVehiculo(miAutocaravana);
                    
                    lineasCorrectas++;
                    
  
                } 
            }

            return lineasCorrectas;

        } catch (Exception ex) {
            System.out.println("Error al leer el equipo desde CSV: " + ex.getMessage());
            return 0;
        }
    }
}
